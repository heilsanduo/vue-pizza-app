<template>
  <div>
    <h1>Home</h1>
    <button @click="goToMenu" class="btn btn-success">Let's order!</button>
  </div>
</template>
<script>
export default {
  methods: {
    goToMenu() {
        //1,返回上一页
    //   this.$router.go(-1);
    //2,指定跳转路由的名字
    // this.$router.replace({name:'menulink'})
    //3,通过push进行跳转
    this.$router.push({name:'loginlink'})
    }
  }
};
</script>
